def a():
    print('Hello World!')